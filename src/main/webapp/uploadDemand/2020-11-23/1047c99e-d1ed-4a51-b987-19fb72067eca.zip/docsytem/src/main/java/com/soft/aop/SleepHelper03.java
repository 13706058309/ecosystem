package com.soft.aop;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class SleepHelper03 {

//    切点
    @Pointcut("execution(public * *.sleep(..))")
    public void sleepProintcut(){
    }

    @Before("sleepProintcut()")
    public void beforeSleep(){
        System.out.println("睡觉前要敷面膜");
    }

    @AfterReturning("sleepProintcut()")
    public void afterSleep(){
        System.out.println("睡觉后要做美梦");
    }








    @Around("sleepProintcut()")
    public void around(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
        System.out.println("环绕开始");
        proceedingJoinPoint.proceed();
        System.out.println("环绕结束");
    }





    @AfterThrowing("sleepProintcut()")
    public void afterThrowing() throws Throwable {
        System.out.println("异常");
    }

    @After("sleepProintcut()")
    public void after() throws Throwable {
        System.out.println("最终增强");
    }
}
