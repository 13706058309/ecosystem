package com.soft.ccq.test;

import com.soft.ccq.dao.IUserDao;
import com.soft.ccq.dao.UserDaoImpl;
import com.soft.ccq.entity.TblUser;

import java.util.List;

public class TestTblUser {
    @Test
    public void testList() {
       List<TblUser> userList = new UserDaoImpl().findUser(1);
        System.out.println(userList.get(0).getLoginName());

    }
}
