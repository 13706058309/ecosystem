package com.soft.ioc;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component()
public class Example {

	public Example() {
		System.out.println("Example 空构造");
	}
	public void run(){
		System.out.printf("厦门马拉松要开始了，你报名了吗？");
	}
	public void init() {
		System.out.println("Example 初始化----");
	}
	public void destroy() {
		System.out.println("Example 消毁---");

	}

}
