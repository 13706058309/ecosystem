package com.soft.ccq.service;

import com.soft.ccq.entity.TblUser;

import java.util.List;


public interface UserService {
    public List<TblUser> findUserAll(String page, String offset);
    public TblUser login(String uname,String pwd);
}
