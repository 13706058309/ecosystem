package com.soft.aop;

/** 
 * 注入形式的Aspcet切面
 */
  
public class SleepHelper04 { 
  public void beforeSleep(){ 
    System.out.println("睡觉前要敷面膜"); 
  } 
  public void afterSleep(){ 
    System.out.println("睡觉后要做美梦"); 
  } 
} 