package com.soft.ccq.dao;

import com.soft.ccq.entity.TblUser;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface UserMapper {
  //  public List<TblUser> findUser(@Param("loginName")String loginName,@Param("offset") String offset,@Param("page") String page);

  public List<TblUser> findUser(Map map);



  public TblUser findUserByName(@Param("uname") String uname, @Param("pwd") String pwd);
}
