package com.soft.ioc;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestIoc {
    public static void main(String[] args) {
        //Computer computer = new Computer("intel","AA","三星");
        // 赋值


        String xml = "applicationContext.xml";
        // 构建容器对象   -- 容器工厂
       ApplicationContext applicationContext =  new  ClassPathXmlApplicationContext(xml);
//        Example example =  applicationContext.getBean("example",Example.class);
//        Example example2 =  applicationContext.getBean("example",Example.class);
//        System.out.println(example);
//        System.out.println(example2);


        Student student =  applicationContext.getBean("student",Student.class);
        System.out.println(student.getComputer());


    }
}
