package com.soft.ccq.util;


import com.soft.ccq.dao.EmpMapper;
import com.soft.ccq.dao.UserDaoImpl;
import com.soft.ccq.entity.Dept;
import com.soft.ccq.entity.TblUser;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import java.io.IOException;
import java.io.Reader;
import java.util.List;

public class MybatisUtil {
    private static SqlSessionFactory sf = null;
    static {
        try {
            String config = "SqlMapConfig.xml";
            Reader reader=null;

            reader= Resources.getResourceAsReader(config);
            SqlSessionFactoryBuilder sfb = new SqlSessionFactoryBuilder();
           sf= sfb.build(reader);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


//    DataSource dataSource = BlogDataSourceFactory.getBlogDataSource();
//    TransactionFactory transactionFactory = new JdbcTransactionFactory();
//    Environment environment = new Environment("development", transactionFactory, dataSource);
//    Configuration configuration = new Configuration(environment);
//configuration.addMapper(
//    BlogMapper.class
//);
//    SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(configuration);
//

    public  static  SqlSession getSession(){
        return sf.openSession();
    }

    public static void main(String[] args) {

      SqlSession session =MybatisUtil.getSession();
        EmpMapper empMapper = session.getMapper(EmpMapper.class);
        Dept dept = empMapper.findDeptByDname("事业部");
        System.out.println(dept);
    }
}
