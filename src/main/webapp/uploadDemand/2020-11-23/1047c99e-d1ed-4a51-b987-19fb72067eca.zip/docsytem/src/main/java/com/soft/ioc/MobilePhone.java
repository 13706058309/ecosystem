package com.soft.ioc;

import org.springframework.stereotype.Component;

@Component("phone")
 public class MobilePhone {
	private String cpu;
	private String ram;

	 public MobilePhone() {
	 }

	 public MobilePhone(String cpu, String ram) {
		super();
		this.cpu = cpu;
		this.ram = ram;
	}
	@Override
	public String toString() {
		return "MobilePhone [cpu=" + cpu + ", ram=" + ram + "]";
	}
	
	

}
