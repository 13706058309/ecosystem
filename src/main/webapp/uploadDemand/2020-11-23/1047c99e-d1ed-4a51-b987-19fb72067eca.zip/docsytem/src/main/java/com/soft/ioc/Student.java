package com.soft.ioc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
/**
 * @author Administrator
 */
@Component
public class Student {

	@Resource
	private Computer computer;

	@Resource
	private MobilePhone phone;

	private List<String> score;
	private String uname;
	private String url;

	 public Student() {
	 }


	public Computer getComputer() {
		return computer;
	}

	public void setComputer(Computer computer) {

		System.out.println("1111");
	 	this.computer = computer;
	}

	public MobilePhone getPhone() {
		return phone;
	}

	public void setPhone(MobilePhone phone) {
		this.phone = phone;
	}

	public List<String> getScore() {
		return score;
	}

	public void setScore(List<String> score) {
		this.score = score;
	}

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}
}
