package com.soft.ccq.dao;

import com.soft.ccq.entity.TblUser;
import com.soft.ccq.util.DbHepler;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class UserDao {
   private Connection conn =null;
   private String sql=null;
   private Statement statement=null;
   private ResultSet rs = null;
   public TblUser login(String uname, String pwd){
       TblUser tblUser = null;
       conn = DbHepler.getConnection();

        return tblUser;
    }

    public List<TblUser> findAllUser(String page,String limit){


       List<TblUser> ulist = new ArrayList<TblUser>();
       try{
           conn = DbHepler.getConnection();
          int begin = (Integer.parseInt(page)-1)*Integer.parseInt(limit);

           sql = "select * from tblUser limit "+begin +","+limit;
           statement =conn.createStatement();
           rs = statement.executeQuery(sql);
           while (rs.next()){
               TblUser user = new TblUser(rs.getInt("userid"),rs.getString("loginname"),
                       rs.getString("truename"),rs.getString("pwd"),
                       rs.getString("state"));
               ulist.add(user);
           }
       }catch (Exception e){
           e.printStackTrace();
       }finally {
           DbHepler.closeResource(conn,statement,rs);
       }
       return  ulist;
    }
}
