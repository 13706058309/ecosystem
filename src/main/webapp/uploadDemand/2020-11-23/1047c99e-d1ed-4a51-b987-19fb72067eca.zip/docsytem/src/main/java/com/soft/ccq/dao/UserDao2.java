package com.soft.ccq.dao;

import com.soft.ccq.entity.TblUser;
import com.soft.ccq.util.DbHepler;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class UserDao2 {
    private Connection conn =null;
    private String sql = null;
    private Statement statement = null;
    private ResultSet rs = null;

    public List<TblUser> findUser(){
        List<TblUser> userList = new ArrayList<TblUser>();
        try {
            conn = DbHepler.getConnection();
            sql = "select * from tbluser";
            statement = conn.createStatement();
            rs = statement.executeQuery(sql);
            while (rs.next()){
                TblUser user = new TblUser(rs.getInt("userid"),rs.getString("loginname"),
                        rs.getString("truename"),rs.getString("pwd"),
                        rs.getString("state"));
                userList.add(user);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DbHepler.closeResource(conn,statement,rs
            );
        }

        return userList;
    }
}
