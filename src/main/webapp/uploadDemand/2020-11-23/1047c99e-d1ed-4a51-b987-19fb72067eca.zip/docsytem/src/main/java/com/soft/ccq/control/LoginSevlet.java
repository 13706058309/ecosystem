package com.soft.ccq.control;

import com.soft.ccq.entity.TblUser;
import com.soft.ccq.service.UserService;
import com.soft.ccq.service.UserServiceImpl;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.annotation.Resource;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;



@WebServlet("/login")
public class LoginSevlet extends HttpServlet {

    private ApplicationContext applicationContext;


    private UserService userServiceImpl;
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String uname = req.getParameter("uname");
        String pwd = req.getParameter("pwd");

        ApplicationContext  applicationContext =
                new ClassPathXmlApplicationContext("applicationContext.xml");

        userServiceImpl = applicationContext.getBean("userServiceImpl",UserServiceImpl.class);

        TblUser user= userServiceImpl.login(uname,pwd);

        if(user != null){
            req.getRequestDispatcher("index.jsp").forward(req,resp);
        }else{
            resp.sendRedirect("adminLogin.jsp");
        }
    }

    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);

    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println("111");
        doPost(req, resp);
    }


}
