package com.soft.aop;

public class ChenLliNa implements Sleepable {
    @Override
    public void sleep() {

        System.out.println("开始睡觉");

    }
}
