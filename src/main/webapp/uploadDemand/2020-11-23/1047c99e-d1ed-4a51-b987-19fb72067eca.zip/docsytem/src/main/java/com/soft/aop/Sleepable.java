package com.soft.aop;

public interface  Sleepable {
    void sleep();

}
