package com.soft.ccq.dao;

import com.soft.ccq.entity.Dept;
import com.soft.ccq.entity.TblUser;

import java.util.List;

public interface IUserDao {

    public List<TblUser> findUser(int id);

}
