package com.soft.ccq.dao;

import com.soft.ccq.entity.Dept;
import com.soft.ccq.entity.Emp;
import com.soft.ccq.util.MybatisUtil;
import org.apache.ibatis.session.SqlSession;

import java.util.List;

public class TestEmp {
    public static void main(String[] args) {
        SqlSession session = MybatisUtil.getSession();
        EmpMapper empMapper = session.getMapper(EmpMapper.class);
//        Emp emp= empMapper.findDeptByEid("刘备备");
//        System.out.println(emp.getEname() +"\t" +emp.getEmpno()+"\t" +emp.getDept().getDname() );
       Dept dept = empMapper.findDeptByDname("事业部");
        System.out.println(dept.getDname());
        List<Emp> empList = dept.getEmpList();
        for (Emp emp: empList
             ) {
            System.out.println(emp.getEname());
        }
    }
}
