package com.soft.ccq.control;

import com.google.gson.Gson;
import com.soft.ccq.entity.TblUser;
import com.soft.ccq.service.UserService;
import com.soft.ccq.service.UserServiceImpl;
import com.soft.ccq.util.TableInfo;

import javax.annotation.Resource;
import javax.annotation.Resources;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet("/userServlet")
public class UserServlet extends HttpServlet {
    @Resource
    private UserService userService ;

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String action = (req.getParameter("action") != null) ? req.getParameter("action") : "list";
        System.out.println("action===="+action);
        TableInfo tableInfo = null;
        switch (action) {
            case "del":
                String loginId = req.getParameter("loginId");
                System.out.println(loginId);
                tableInfo = new TableInfo(200, "用户删除返回成功", 10, null);
                break;
            case "list":
                String page = req.getParameter("page");
                String limit = req.getParameter("limit");
                System.out.println(page);
                System.out.println(limit);
                //得到用户的所有信息
                List<TblUser> ulist = userService.findUserAll(page,limit);
                tableInfo = new TableInfo(200, "用户列表数据返回成功", 10, ulist);
                break;
            case "login":
                String uname = req.getParameter("uname");
                String pwd = req.getParameter("pwd");
                TblUser user= userService.login(uname,pwd);
                break;
            default:
                break;
        }
        resp.setContentType("text/html;charset=UTF-8");
        PrintWriter out = resp.getWriter();
        out.print(new Gson().toJson(tableInfo));
        out.flush();
        out.close();


    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }
}
