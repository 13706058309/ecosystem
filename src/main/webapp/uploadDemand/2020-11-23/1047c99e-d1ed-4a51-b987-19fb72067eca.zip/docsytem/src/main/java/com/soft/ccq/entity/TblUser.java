package com.soft.ccq.entity;

public class TblUser {
    private int loginId;
    private String loginName;
    private String trueName;
    private String pwd;
    private String state;

    public TblUser() {

    }

    public TblUser(int loginId, String loginName, String trueName, String pwd, String state) {
        this.loginId = loginId;
        this.loginName = loginName;
        this.trueName = trueName;
        this.pwd = pwd;
        this.state = state;
    }

    public int getLoginId() {
        return loginId;
    }

    public void setLoginId(int loginId) {
        this.loginId = loginId;
    }

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public String getTrueName() {
        return trueName;
    }

    public void setTrueName(String trueName) {
        this.trueName = trueName;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }
}
