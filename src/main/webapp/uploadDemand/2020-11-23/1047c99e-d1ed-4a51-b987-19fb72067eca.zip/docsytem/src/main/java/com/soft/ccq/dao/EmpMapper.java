package com.soft.ccq.dao;

import com.soft.ccq.entity.Dept;
import com.soft.ccq.entity.Emp;


public interface EmpMapper {
//	public List<Emp> findAll();
//	public List<Emp> findByDept(Condition cond);
//	public List<Emp> findBySalary(Condition cond);
//	public List<Emp> findByDeptAndSalary(Condition cond);
//	public void update(Emp emp);
//
//	public List<Emp> findByDeptAndSalary2(Condition cond);
//	public void update2(Emp emp);
//	List<Emp>findByIds(Condition cond);

	public Emp findDeptByEid(String ename);

	public Dept findDeptByDname(String dname);
}
