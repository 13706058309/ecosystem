package com.soft.ccq.entity;

public class TblUser2 {
    private  String loginid;
    private String uname;
    private Emp emp;

    public TblUser2() {

    }

    public TblUser2(String loginid, String uname) {
        this.loginid = loginid;
        this.uname = uname;
    }

    public String getLoginid() {
        return loginid;
    }

    public void setLoginid(String loginid) {
        this.loginid = loginid;
    }

    public String getUname() {
        return uname;
    }

    public void setUname(String uname) {
        this.uname = uname;
    }
}
