package com.soft.ccq.service;

import com.soft.ccq.dao.UserMapper;
import com.soft.ccq.entity.TblUser;
import com.soft.ccq.util.MybatisUtil;
import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
@Service
public class UserServiceImpl implements  UserService {
    private UserMapper userMapper;

    private SqlSession session = null;
    @Override
    public List<TblUser> findUserAll(String page,String offset) {
//        session = MybatisUtil.getSession();
//        UserMapper userMapper = session.getMapper(UserMapper.class);
        Map map = new HashMap<String,String>();
        map.put("offset",offset);
        map.put("page",page);
        map.put("loginName","%张%");

        return userMapper.findUser(map);
    }

    @Override
    public TblUser login(String uname, String pwd) {
        session = MybatisUtil.getSession();
        UserMapper userMapper = session.getMapper(UserMapper.class);

        return userMapper.findUserByName(uname,pwd);
    }
}
