package com.soft.ccq.control;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.servlet.*;
import java.io.IOException;

public class ServiceInfoServletProxy extends GenericServlet {

    private String targetBean;
    private Servlet proxy;

    @Override
    public void init() throws ServletException {
        // TODO Auto-generated method stub
        this.targetBean = getServletName();
        getServletBean();
        proxy.init(getServletConfig());
    }

    @Override
    public void service(ServletRequest req, ServletResponse res)
            throws ServletException, IOException {
        // TODO Auto-generated method stub
        proxy.service(req, res);
    }

    private void getServletBean(){
        WebApplicationContext wac = WebApplicationContextUtils.getRequiredWebApplicationContext(getServletContext());
        this.proxy = (Servlet) wac.getBean(targetBean);
    }
}
