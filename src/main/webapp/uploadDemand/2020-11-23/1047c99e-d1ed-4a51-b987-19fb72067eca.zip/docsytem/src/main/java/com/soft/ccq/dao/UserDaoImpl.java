package com.soft.ccq.dao;

import com.soft.ccq.entity.TblUser;
import com.soft.ccq.util.MybatisUtil;
import org.apache.ibatis.session.SqlSession;

import java.util.List;

public class UserDaoImpl implements IUserDao {
    private SqlSession session;

    @Override
    public List<TblUser> findUser(int id) {

        session = MybatisUtil.getSession();
        IUserDao mapper = session.getMapper(IUserDao.class);
        return mapper.findUser(new Integer(1));
    }
}
