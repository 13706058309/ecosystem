package com.soft.ccq.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class DbHepler {

    public static Connection getConnection (){
        Connection conn = null;
        try {
            //2.  注册和加载数据库驱动程序
            Class.forName("com.mysql.jdbc.Driver");
            String url="jdbc:mysql://localhost:3306/docsys?characterEncoding=utf8&useSSL=false&serverTimezone=UTC&rewriteBatchedStatements=true";
            conn = DriverManager.getConnection(url,"root","123456");
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    return conn;
    }


    public static  void closeResource(Connection conn, Statement statement , ResultSet rs){
       try {
           if (null != rs) {
               rs.close();
           }
           if (null != statement) {
               statement.close();
           }
           if (null != conn) {
               conn.close();
           }
       }catch (Exception e){
           e.printStackTrace();
       }
    }


}
